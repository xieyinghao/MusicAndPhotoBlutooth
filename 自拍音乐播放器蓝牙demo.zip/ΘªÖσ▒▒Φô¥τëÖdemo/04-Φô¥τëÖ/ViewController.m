//
//  ViewController.m
//  04-蓝牙
//
//  Created by vera on 16/10/14.
//  Copyright © 2016年 deli. All rights reserved.
//
//static NSString *ServicesUUID   = @"FFF0";// heart 服务UUID
//static NSString *NotifyUUID = @"FFF1";// 通知 通知UUID
//static NSString *WriteUUID   = @"FFF2";//写    服务UUID
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "ViewController.h"
#import "XYHUIImagePickerController.h"
#import "BlueToothManager.h"
#import <CallKit/CallKit.h>
#import "UnityTool.h"
#import <CoreTelephony/CTCallCenter.h>  
#import <CoreTelephony/CTCall.h>
//音乐播放
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate>
@property(nonatomic,strong)UILabel *la;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)CTCallCenter *callCenter;


@property (strong, nonatomic) MPMusicPlayerController *musicPlayerController; //音乐播放器
@property (assign, nonatomic) MPMusicPlaybackState musicPlaybackState; //播放状态
@property (strong, nonatomic) MPMediaQuery *query; //媒体队列
@property(nonatomic)BOOL isPlayMusic;
@property(nonatomic)BOOL isPause;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
//    NSLog(@"=====data:=%@======",data);
    
    
   //初始化
    BlueToothManager *manager = [BlueToothManager shareManager];

    
    //设置扫描成功的回调
    [manager setBlueToothDidScanPeripheralsCallback:^(NSArray *peripherals) {
        
        [self handleSacnPeripherals:peripherals];
        
    }];
    
    //扫描
    [manager scan];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(senddata) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    self.la = [[UILabel alloc]initWithFrame:CGRectMake(200, 200, 100, 100)];
    [self.view addSubview:self.la];
    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, ScreenW, ScreenH-64) style:UITableViewStylePlain];;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeValue) name:@"zipai" object:nil];
    
      [self music];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(systemMusicPlayerControltest:) name:@"musicPlay" object:nil];
    
  
}
#pragma =====================音乐播放=====================================

#pragma =====================音乐播放=====================================

     //APPdelegate  需要添加的文件
//- (void)applicationWillResignActive:(UIApplication *)application {
//    //后台支持接收远程控制事件
//    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
//    //核心代码
//    AVAudioSession *session = [AVAudioSession sharedInstance];
//    
//    [session setCategory:AVAudioSessionCategoryPlayback error:nil]; //后台播放
//    [session setActive:YES error:nil];
//}
- (void)music{
    NSLog(@"systemVersion==%f",[[UIDevice currentDevice] systemVersion].floatValue);
    if ([[UIDevice currentDevice] systemVersion].floatValue >= 8.0) {
        self.musicPlayerController =  [MPMusicPlayerController applicationMusicPlayer];//初始化系统音乐播放器
    }else{
        self.musicPlayerController =  [MPMusicPlayerController applicationMusicPlayer];
        
    }
    self.musicPlaybackState = self.musicPlayerController.playbackState;
    if (![self isPlayingItem]  ) {
        [self getMusicListFromMusicLibrary];
    }
    self.isPlayMusic = YES;
}

// 判断有没有正在播放的媒体项目
//- (BOOL)isPlayingItem {
//    if ([self.musicPlayerController indexOfNowPlayingItem] == NSNotFound) {
//        return NO;
//    } else {
//        return YES;
//    }
//}
// 判断有没有正在播放的媒体项目
- (BOOL)isPlayingItem {
    if ([self.musicPlayerController indexOfNowPlayingItem] == NSNotFound) {
        return NO;
    } else {
        return YES;
    }
}
//创建媒体队列
- (void)createMediaQuery {
    self.query = [MPMediaQuery songsQuery];
    [self.musicPlayerController setQueueWithQuery:self.query];
}
- (MPMediaItemCollection *)getMusicListFromMusicLibrary {
    self.query = [MPMediaQuery songsQuery];
    // 申明一个Collection便于下面给MusicPlayer赋值
    MPMediaItemCollection *mediaItemCollection;
    if (self.query.items.count == 0) {
        return 0;
    } else {
        //获取本地音乐库文件
        NSMutableArray *musicArray= [NSMutableArray array];
        for(MPMediaItem *item in self.query.items) {
            [musicArray addObject:item];
            NSLog(@"%@",item.title);
        }
        // 将音乐信息赋值给musicPlayer
        mediaItemCollection = [[MPMediaItemCollection alloc] initWithItems:[musicArray copy]];
        [self.musicPlayerController setQueueWithItemCollection:mediaItemCollection];
    }
    
    return mediaItemCollection;
}
//暂停或者播放音乐的代码实现：
- (void)musicPlay{
    [self music];
    NSLog(@"%lu",(unsigned long)self.musicPlayerController.indexOfNowPlayingItem);
    if (self.musicPlaybackState == MPMusicPlaybackStatePlaying) {
        [self.musicPlayerController pause];//暂停
        self.musicPlaybackState = MPMusicPlaybackStatePaused;
        
    }else if (self.musicPlaybackState == MPMusicPlaybackStateStopped || self.musicPlaybackState == MPMusicPlaybackStatePaused || self.musicPlaybackState == MPMusicPlaybackStateInterrupted) {
        [self.musicPlayerController play]; //播放
        self.musicPlaybackState = MPMusicPlaybackStatePlaying;
        
    }
    
}
//实现上一曲的代码：
- (void)musicBack{
    
    if (self.musicPlaybackState != MPMusicPlaybackStatePlaying) {
        [self music];
    }
    [self.musicPlayerController play];
    [self.musicPlayerController skipToPreviousItem];
    self.musicPlaybackState = MPMusicPlaybackStatePlaying;
    
}
//实现下一曲的代码：
- (void)musicNext{
    
    if (self.musicPlaybackState != MPMusicPlaybackStatePlaying) {
        [self music];
    }
    
    [self.musicPlayerController play];
    self.isPause = NO;
    [self.musicPlayerController skipToNextItem];
    self.musicPlaybackState = MPMusicPlaybackStatePlaying;
    
}
- (void)systemMusicPlayerControltest:(NSNotification *)notification {
    
    //音乐播放 <f60102> 上一首  <f60103>下一首  <f60101>暂停与播放
    NSData *data = notification.object;  //蓝牙设备传来的控制信息
    Byte *bytes = (Byte *)[data bytes];
    self.musicPlaybackState = self.musicPlayerController.playbackState;
    if (bytes[1] == 0x01) {  //验证
        if (![self isPlayingItem]) {
            [self createMediaQuery];  //若没有正在播放的媒体项目，则创建媒体队列
        }
        if (bytes[2] == 0x01) { // 播放/停止
            
            if (self.musicPlaybackState == MPMusicPlaybackStatePlaying) {
                 [self  musicPlay]; //播放
                NSLog(@"暂停Music Control Error Data!");
            }
            if (self.musicPlaybackState == MPMusicPlaybackStateStopped || self.musicPlaybackState == MPMusicPlaybackStatePaused || self.musicPlaybackState == MPMusicPlaybackStateInterrupted) {
                [self  musicPlay]; //播放
                NSLog(@"播放Music Control Error Data!");
            }
        } else if (bytes[2] == 0x02) { // 切换上一曲
             [self  musicBack]; //播放
            NSLog(@"切换上一曲Music Control Error Data!");
        } else if (bytes[2] == 0x03) { // 切换下一曲
              [self  musicNext]; //播放
            NSLog(@"切换下一曲Music Control Error Data!");
        } else {
            NSLog(@"Music Control Error Data!");
        }
    }
    
}
#pragma =========================================================
-(void)changeValue
{
    
//    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
//    {
//        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;//设置类型为相机
//        UIImagePickerController *picker = [[UIImagePickerController alloc] init];//初始化
//        picker.delegate = self;//设置代理
//        picker.allowsEditing = YES;//设置照片可编辑
//        picker.sourceType = sourceType;
//        //设置是否显示相机控制按钮 默认为YES
//        picker.showsCameraControls = YES;
//        
//        //        //创建叠加层(例如添加的相框)
//        //        UIView *overLayView=[[UIView alloc]initWithFrame:CGRectMake(0, 120, 320, 254)];
//        //        //取景器的背景图片，该图片中间挖掉了一块变成透明，用来显示摄像头获取的图片；
//        //        UIImage *overLayImag=[UIImage imageNamed:@"zhaoxiangdingwei.png"];
//        //        UIImageView *bgImageView=[[UIImageView alloc]initWithImage:overLayImag];
//        //        [overLayView addSubview:bgImageView];
//        //        picker.cameraOverlayView=overLayView;
//        
//        //选择前置摄像头或后置摄像头
//        picker.cameraDevice=UIImagePickerControllerCameraDeviceFront;
//        [self presentViewController:picker animated:YES completion:^{
//        }];
//    }
//    else {
//        NSLog(@"该设备无相机");  
//    }
    
    XYHUIImagePickerController *vc = [[XYHUIImagePickerController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
    
}


#pragma mark - image picker
-(void)senddata
{
//    固件升级模式 <01010000 00000000 00000000 00000000 00000000>
//    [self sendFirmwareUpdata];
    
//    app发送获得设备基本信息请求  <02010000 00000000 00000000 00000000 00000000>
//    [self sendBaseData];
    
//    获得设备的时间  <02030000 00000000 00000000 00000000 00000000>
//    [self sendDataForTime];
    
//    获得设备 mac 地址 <02040000 00000000 00000000 00000000 00000000>
//    [self sendDataForMAC];
    
//    获得设备电池信息 <02050000 00000000 00000000 00000000 00000000>
//    [self sendDataForLevel];
    
//    时间设置   星期(0~6, 从星期一到 星期天)如果周一，week_day传0   <03011014 0b0c0c0c 1e010000 00000000 00000000>
//    [self sendDataForEditTimetoYear:16 month:11 day:12 hour:12 minute:12 second:30 week_day:1];
    
//    闹钟提醒设置 StatusString== yes -> 0x00   Repetitions:@"11111111"->二进制转16进制   <03020900 040914ff 00000000 00000000 000000>
//    [self sendDataForClockNumber:9 AndStatus:YES AndType:@"约会" AndHour:9 AndMinute:20 AndRepetitions:@"11111111"];
    
//    用户信息设置    <0310aa32 01000000 00000000 00000000 00000000>
//    [self sendDataForConsumerMassage:170 AndWeight:50 AndGender:@"女"];
    
//    久坐提醒设置  <03200e0f 0e1e0f00 00000000 00000000 000000>
//    [self sendDataForLongSitStartHour:14 AndStartMinute:15 AndEndHour:14 AndEndMinute:30 AndInterval:15 AndRepetitions:@"00000000"];
    
//    抬腕手势开关设置  yes-> 0x00->打开  <03280003 00000000 00000000 00000000 00000000>
//    [self sendDataForSwitch:YES];
    
//    解除绑定 <040255aa 55aa0000 00000000 00000000 00000000>
//    [self sendDataForRidTie];
    
//    来电提醒  来电提醒:<05014952 55495648 57534852 54000000 00000000>
//    [self sendDataForComingPhone:@"14718095046"];
    
//    信息提醒:<05034952 55495648 57534852 54000000 00000000>
//     [self sendDataForComingSMS:@"14718095046"];
    
//    寻找手环:<06040000 00000000 00000000 00000000 00000000>
//    [self sendDataForLookForEquipment];
    
//    事件控制<07010100 00000000 00000000 00000000 00000000>
//    [self sendDataForPlayMusicOfType:@"开始"];
    
//    事件控制<07010800 00000000 00000000 00000000 00000000>
//     [self sendDataForPlayMusicOfType:@"音量增"];
    
    [self sendStepsData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 10;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
#pragma =========================连接外部设备====================================================================
///连接外部设备
- (void)handleSacnPeripherals:(NSArray *)peripherals
{
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    __weak BlueToothManager *weakManager = manager;
    
    //扫描到外部设备
    CBPeripheral *peripheral = peripherals.firstObject;
    //过滤外设，当前缀为SMART的外设才进行连接
//    if ([peripheral.name hasPrefix:@"SMART"]) {
//        
//        //连接外部设备
//        [weakManager connect:peripheral];
//        NSLog(@"连接成功");
//    }
    [weakManager connect:peripheral];

    
}
#pragma =========================app发送获得设步数(这个不是香山协议里面的)===============================
/**
 发送数据
 */
- (void)sendStepsData
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
//    Byte byte[2];
//    byte[0] = 0x02; //command_id
//    byte[1] = 0x01;  //key
//    
//    NSData *data = [NSData dataWithBytes:byte length:2];
//    Byte byte1[4];
//    byte1[0] = 0xC6;
//    byte1[1] = 0x01;
//    byte1[2] = 0x08;
//    byte1[3] = 0x08;
//  
//    NSData *data1 = [NSData dataWithBytes:byte1 length:4];
//    NSLog(@"%@",data1);
    
    
    //设置时间
    Byte byte1[10];
    byte1[0] = 0XC2;
    byte1[1] = 0X07;
    byte1[2] = 0x10;//16年
    byte1[3] = 0x0c;//12月
    byte1[4] = 0x0d;//13日
    byte1[5] = 0x0e;//14时
    byte1[6] = 0x00;//41分
    byte1[7] = 0x00;//14秒
    byte1[8] = 0x01;//周二
    byte1[9] = byte1[2]^byte1[3]^byte1[4]^byte1[5]^byte1[6]^byte1[7]^byte1[8];
    NSData *data1 = [NSData dataWithBytes:byte1 length:10];
    NSLog(@"%@",data1);
    
    //睡眠
//    Byte byte1[6];
//    byte1[0] = 0xC4;
//    byte1[1] = 0x03;
//    byte1[2] = 0x07;//周六
//    byte1[3] = 0x17;//23点
//    byte1[4] = 0x03;//代表返回的是1个小时的间隔时间 同理02 03
//
//    byte1[5] = byte1[2]^byte1[3]^byte1[4];
//    NSData *data1 = [NSData dataWithBytes:byte1 length:6];
//    NSLog(@"%@",data1);
    
    //睡眠数据处理
    
//    Byte NewBytes[] = {bytes[5]};
//    int bit ={NewBytes[1]};
//    //    int bit =0x02;
//    int position = 0;
//    int vol = bit>>position;
//    NSLog(@"第一位vol========%d",(vol & 0x01));
//    
//    int position1 = 1;
//    int vol1 = bit>>position1;
//    NSLog(@"第二位vol1========%d",(vol1 & 0x01));
//    
//    NSLog(@"已经收到转换数据bitbitbit==========%hhu=============",bit);
//    NSLog(@"已经收到转换数据==========%hhu=============",NewBytes);
//    
//    Byte firstBt = bytes[5];
//    
//    Byte secondBt = bytes[6];
//    
//    Byte new = 0;
//    
//    for(int i = 5; i >= 0; --i)
//    {
//        new += ((firstBt >> i) & 0x01) *2^13/2^(5-i);
//    }
//    for(int i = 7; i >= 0; --i)
//    {
//        new += ((secondBt >> i) & 0x01) *2^7/2^(7-i);
//    }
//    
//    NSLog(@"=======new=====%d================",new);
    
    //
//    Byte byte1[8];
//    byte1[0] = 0x84;//设置饮水闹钟
//    byte1[1] = 0x05;
//    byte1[2] = 0x01;//打开0x01  关闭0x00
//    byte1[3] = 0x0d;//14点
//    byte1[4] = 0x37;//开始分钟,默认30
//    byte1[5] = 0x05;//5分钟间隔  默认30
//    byte1[6] = 0x01;// 重复次数 默认0
//    byte1[7] = byte1[2]^byte1[3]^byte1[4]^byte1[5]^byte1[6];
//    NSData *data1 = [NSData dataWithBytes:byte1 length:8];
//    NSLog(@"%@",data1);
        //获得设备基本信息
        [[BlueToothManager shareManager] writeData:data1 characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleStepsValue:value];
        
    }];
}


/**
 处理硬件返回的数据

 @param data <#data description#>
 */
- (void)handleStepsValue:(NSData *)data
{
     NSLog(@"==========datatatat已经收到数据==========%@",data);
    Byte *bytes = (Byte *)data.bytes;
    
//    Byte NewBytes[] = {bytes[6],bytes[7]};
    

    
    Byte NewBytes[] = {bytes[5]};
    int bit ={NewBytes[1]};
    //    int bit =0x02;
    int position = 0;
    int vol = bit>>position;
    NSLog(@"第一位vol========%d",(vol & 0x01));
    
    int position1 = 1;
    int vol1 = bit>>position1;
    NSLog(@"第二位vol1========%d",(vol1 & 0x01));
    
    NSLog(@"已经收到转换数据bitbitbit==========%hhu=============",bit);
    NSLog(@"已经收到转换数据==========%hhu=============",NewBytes);
    
    
    
    NSLog(@"%s",bytes);
    Byte firstBt = bytes[5];
    Byte secondBt = bytes[6];
    Byte new = firstBt &0x3F;
    
    
    Byte news[] = {new,secondBt};
    NSData *Newdata = [[NSData alloc] initWithBytes:news length:2];
    Byte *Newbytes = (Byte*)Newdata.bytes;
    NSLog(@"=====Newbytes=======%s========",Newbytes);
    
    
    //command_id
    Byte command_id = bytes[0];
    //key
    Byte key = bytes[1];
    
    //获得设备基本信息
    if (command_id == 0x24 && key == 0x70)
    {
        //固件版本号
        //固件版本号
        Byte *byte = (Byte *)[data bytes];
        Byte b[] = {byte[2],byte[3],byte[4]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        
        NSLog(@"已经收到数据==========%ld",weight);
        self.la.text = [NSString stringWithFormat:@"步数%ld",weight];
    }

}

#pragma =========================固件升级模式(command_id 为 0x01, key 为 0x01)================================================
/**
 发送数据
 */
- (void)sendFirmwareUpdata
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x01; //command_id
    byte[1] = 0x01;  //key
    byte[2] = 0x00;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
      NSLog(@"===========固件升级模式:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleFirmwareUpdataValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleFirmwareUpdataValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
   
    Byte  byteState = byte[2];
    //获得设备基本信息
    if (command_id == 0x01 && key == 0x01)
    {
        
//    0x00: 进入 OTA 成功 0x01: 失败:电量过低
        
        
        if (byteState == 0x00) {
            
            NSLog(@"进入OTA成功");
        }else
        {
            NSLog(@"电量过低");
            
        }
        
    
    }
    
}
#pragma =========================app发送获得设备基本信息请求======================================================
/**
 发送数据
 */
- (void)sendBaseData
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x02; //command_id
    byte[1] = 0x01;  //key
    byte[2] = 0x00;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
     NSLog(@"===========app发送获得设备基本信息请求:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleBaseValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleBaseValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x01)
    {
        //固件版本号
        //固件版本号
        Byte b[] = {byte[3]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        NSLog(@"固件版本号：%llu",weight);
    }
    
}
#pragma ===========================获得设备的时间(command_id 为 0x02, key 为 0x03)=======================================
/**
 发送数据
 */
- (void)sendDataForTime
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x02; //command_id
    byte[1] = 0x03;  //key
    byte[2] = 0x00;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
     NSLog(@"===========获得设备的时间:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleTimeValue:value];
         NSLog(@"已经收到数据");
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleTimeValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x03)
    {
        //年
        Byte b[] = {byte[0],byte[1]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 year = strtoul([str UTF8String], 0, 16);
        NSLog(@"%llu年",year);
        //月
        Byte monthByte[] = {byte[2]};
        NSData *monthdata = [[NSData alloc] initWithBytes:monthByte length:sizeof(monthByte)];
        NSString *monthstr = [monthdata ConvertToNSString];
        UInt64 month = strtoul([monthstr UTF8String], 0, 16);
        NSLog(@"%llu月",month);
        //日
        Byte dateByte[] = {byte[3]};
        NSData *datedata = [[NSData alloc] initWithBytes:dateByte length:sizeof(dateByte)];
        NSString *datestr = [datedata ConvertToNSString];
        UInt64 date = strtoul([datestr UTF8String], 0, 16);
        NSLog(@"%llu日",date);
        //时
        Byte hourByte[] = {byte[4]};
        NSData *hourdata = [[NSData alloc] initWithBytes:hourByte length:sizeof(hourByte)];
        NSString *hourstr = [hourdata ConvertToNSString];
        UInt64 hour = strtoul([hourstr UTF8String], 0, 16);
        NSLog(@"%llu时",hour);
        //分
        Byte MinuteByte[] = {byte[5]};
        NSData *Minutedata = [[NSData alloc] initWithBytes:MinuteByte length:sizeof(MinuteByte)];
        NSString *Minutestr = [Minutedata ConvertToNSString];
        UInt64 Minute = strtoul([Minutestr UTF8String], 0, 16);
           NSLog(@"%llu分",Minute);
        //秒
        Byte SecondByte[] = {byte[6]};
        NSData *Seconddata = [[NSData alloc] initWithBytes:SecondByte length:sizeof(SecondByte)];
        NSString *Secondstr = [Seconddata ConvertToNSString];
        UInt64 Second = strtoul([Secondstr UTF8String], 0, 16);
        NSLog(@"%llu秒",Second);
        //周几
        Byte WeekdayByte[] = {byte[7]};
        NSData *Weekdaydata = [[NSData alloc] initWithBytes:WeekdayByte length:sizeof(WeekdayByte)];
        NSString *Weekdaystr = [Weekdaydata ConvertToNSString];
        UInt64 Weekday = strtoul([Weekdaystr UTF8String], 0, 16);
        switch (Weekday) {
            case 0:
                  NSLog(@"这是周一");
                break;
            case 1:
                NSLog(@"这是周二");
                break;

            case 2:
                NSLog(@"这是周三");
                break;

            case 3:
                NSLog(@"这是周四");
                break;

            case 4:
                NSLog(@"这是周五");
                break;

            case 5:
                NSLog(@"这是周六");
                break;

            case 6:
                NSLog(@"这是周日");
                break;

                
            default:
                break;
        }

    }
    
}
#pragma ===========================获得设备 mac 地址(command_id 为 0x02, key 为 0x04)=======================================
/**
 发送数据
 */
- (void)sendDataForMAC
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x02; //command_id
    byte[1] = 0x04;  //key
    byte[2] = 0x00;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"===========获得设备 mac 地址:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleMACValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleMACValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x04)
    {
         Byte mac0 = byte[2];
         Byte mac1 = byte[3];
         Byte mac2 = byte[4];
         Byte mac3 = byte[5];
         Byte mac4 = byte[6];
         Byte mac5 = byte[7];
        //mac地址拼接
        NSString *MacString = [NSString stringWithFormat:@"%hhu:%hhu:%hhu:%hhu:%hhu:%hhu",mac0,mac1,mac2,mac3,mac4,mac5];
        NSLog(@"mac地址：%@",MacString);
    }
    
}
#pragma ===========================获得设备电池信息(command_id 为 0x02, key 为 0x05)=======================================
/**
 发送数据
 */
- (void)sendDataForLevel
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x02; //command_id
    byte[1] = 0x05;  //key
    byte[2] = 0x00;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"===========获得设备电池信息:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleLevelValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleLevelValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x05)
    {
        //固件版本号
        //固件版本号
        Byte b[] = {byte[6]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        NSLog(@"%llu电量：%%\n",weight);
    }
    
}
#pragma ===========================时间设置(command_id 为 0x03, key 为 0x01)=======================================
/**
 发送数据
 */
- (void)sendDataForEditTimetoYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day hour:(NSInteger)hour  minute :(NSInteger)minute second:(NSInteger)second week_day:(NSInteger)week_day
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x03; //command_id
    byte[1] = 0x01;  //key
    byte[2]=(Byte)(0XFF & year);
    byte[3] = 0x14;
    byte[4]=(Byte)(0XFF & month);
    byte[5]=(Byte)(0XFF & day);
    byte[6]=(Byte)(0XFF & hour);
    byte[7]=(Byte)(0XFF & minute);
    byte[8]=(Byte)(0XFF & second);
    byte[9]=(Byte)(0XFF & week_day);
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
//    月(有效值: 在 1~12)
//    日(有效值: 在 1~31
//    时(有效 值 0~23)
//    分(有效 值 0~59)
//    秒(有效 值 0~59
//    星期(0~6, 从星期一到 星期天)
    NSData *data = [NSData dataWithBytes:byte length:20];
     NSLog(@"===========时间设置:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleEditTimeValue:value];
     }];
}

/**
 处理硬件返回的数据
 
 */
- (void)handleEditTimeValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x03 && key == 0x01)
    {
        NSLog(@"设置时间成功");
    }
    
}
#pragma =========================闹钟提醒设置(command_id 为 0x03, key 为 0x02)======================================
/**
 发送数据
 */
- (void)sendDataForClockNumber:(NSInteger)nuemer AndStatus:(BOOL)status AndType:(NSString*)type AndHour:(NSInteger)hour AndMinute:(NSInteger)minute AndRepetitions:(NSString*)repetitions
{
    NSString *uuid = @"FFF2";
    
    NSString *NumberString = [NSString stringWithFormat:@"%@",[self ToHex:nuemer]];
    NSString *StatusString ;
    if (status == YES) {
        StatusString = @"00";
        
    }else
    {
         StatusString = @"01";
    }
    NSString *typeString;
    if ([type isEqualToString:@"起床"]) {
        
       typeString = @"00";
    }else if ([type isEqualToString:@"睡觉"]){
        
        typeString = @"01";
    }else if ([type isEqualToString:@"锻炼"]){
        
       typeString = @"02";
    }else if ([type isEqualToString:@"吃药"]){
        
        typeString = @"03";
    }else if ([type isEqualToString:@"约会"]){
        
        typeString = @"04";
    }else if ([type isEqualToString:@"聚会"]){
        
        typeString = @"05";
    }else if ([type isEqualToString:@"会议"]){
        
        typeString = @"06";
    }else if ([type isEqualToString:@"自定义"]){
        
        typeString = @"07";
    }
      NSString *hourString = [NSString stringWithFormat:@"%@",[self ToHex:hour]];
     NSString *minuteString = [NSString stringWithFormat:@"%@",[self ToHex:minute]];
    NSString *repetitionsString = [self getBinaryByhex:nil binary:repetitions];
   
    NSLog(@"==========闹钟提醒设置:%@==========", [self hexToBytes:[NSString stringWithFormat:@"0302%@%@%@%@%@%@00000000000000000000000",NumberString,StatusString,typeString,hourString,minuteString,repetitionsString]]);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:  [self hexToBytes:[NSString stringWithFormat:@"0302%@%@%@%@%@%@00000000000000000000000",NumberString,StatusString,typeString,hourString,minuteString,repetitionsString]] characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleClockValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleClockValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x05)
    {
        //固件版本号
        //固件版本号
        Byte b[] = {byte[6]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        NSLog(@"%llu电量：%d%%\n",weight);
    }
    
}
#pragma ===========================目标设置(command_id 为 0x03, key 为 0x03)==========================================

#pragma ===========================用户信息设置(command_id 为 0x03, key 为 0x10)=======================================
/**
发送数据
*/
- (void)sendDataForConsumerMassage:(NSInteger)height AndWeight:(NSInteger)Weight AndGender:(NSString*)Gender
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x03; //command_id
    byte[1] = 0x10;  //key
    byte[2]=(Byte)(0XFF & height);
    byte[3]=(Byte)(0XFF & Weight);
    if ([Gender isEqualToString:@"男"]) {
        
        byte[4] = 0x00;
    }else
    {
        byte[4] = 0x01;
    }
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"===========用户信息设置:%@============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleConsumerMassagetValue:value];
     }];
}

/**
 处理硬件返回的数据
 
 */
- (void)handleConsumerMassagetValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    Byte states = byte[2];
    //获得设备基本信息
    if (command_id == 0x03 && key == 0x10)
    {
        if ( states == 0x00) {
            
            NSLog(@"设置个人信息成功");
        }else
        {
            NSLog(@"设置个人信息失败");
        }
       
        
    }
    
}
#pragma ===========================久坐提醒设置(command_id 为 0x03, key 为 0x20)=======================================
/**
 发送数据
 */
- (void)sendDataForLongSitStartHour:(NSInteger)StartHour AndStartMinute:(NSInteger)minuteime AndEndHour:(NSInteger)endhour AndEndMinute:(NSInteger)endminute AndInterval:(NSInteger)interval AndRepetitions:(NSString *)epetitions
{
    NSString *uuid = @"FFF2";
    NSString *StartHourString = [NSString stringWithFormat:@"%@",[self ToHex:StartHour]];
    NSString *minuteimeString = [NSString stringWithFormat:@"%@",[self ToHex:minuteime]];
    NSString *endhourString = [NSString stringWithFormat:@"%@",[self ToHex:endhour]];
    NSString *endminuteString = [NSString stringWithFormat:@"%@",[self ToHex:endminute]];
    NSString *intervalString = [NSString stringWithFormat:@"%@",[self ToHex:interval]];
    NSString *repetitionString = [self getBinaryByhex:nil binary:epetitions];
    
    NSLog(@"=============久坐提醒设置%@==========",[self hexToBytes:[NSString stringWithFormat:@"0320%@%@%@%@%@%@0000000000000000000000",StartHourString,minuteimeString,endhourString,endminuteString,intervalString,repetitionString]]);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:  [self hexToBytes:[NSString stringWithFormat:@"0320%@%@%@%@%@%@0000000000000000000000",StartHourString,minuteimeString,endhourString,endminuteString,intervalString,repetitionString]] characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleLongSitValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleLongSitValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x03 && key == 0x20)
    {
  
    }
    
}
#pragma ===========================抬腕手势开关设置(command_id 为 0x03, key 为 0x28)=======================================
/**
 发送数据
 */
- (void)sendDataForSwitch:(BOOL)open
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x03; //command_id
    byte[1] = 0x28;  //key
    if (open == YES) {
        
        byte[2] = 0x00;
    }else
    {
        byte[2] = 0x01;
    }
    byte[3] = 0x03;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"============抬腕手势开关设置%@=============",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleSwitchValue:value];
     }];
}

/**
 处理硬件返回的数据
 
 */
- (void)handleSwitchValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    Byte isOpenState = byte[2];
    //抬腕手势开关设置
    if (command_id == 0x03 && key == 0x28)
    {
        if ( isOpenState == 0x00) {
            
            NSLog(@"抬腕手势开关设置成功");
        }else
        {
            NSLog(@"抬腕手势开关设置失败");
        }
    }
}
#pragma ===========================解除绑定(command_id 为 0x04, key 为 0x02)=======================================
/**
 发送数据
 */
- (void)sendDataForRidTie
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x04; //command_id
    byte[1] = 0x02;  //key
    byte[2] = 0x55;
    byte[3] = 0xAA;
    byte[4] = 0x55;
    byte[5] = 0xAA;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"=============解除绑定:%@==========",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleRidTieValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleRidTieValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    Byte resule = byte[2];
    //获得设备基本信息
    if (command_id == 0x04 && key == 0x02)
    {
        if (resule == 0x00) {
            
             NSLog(@"解绑成功");
        }else
        {
             NSLog(@"解绑失败");
        }
        
    }
    
}
#pragma ===========================来电提醒(command_id 为 0x05, key 为 0x01)=================================================
/**
 发送数据
 */

- (void)sendDataForComingPhone:(NSString *)phoneString
{
    NSString *uuid = @"FFF2";
    
    NSLog(@"========来电提醒:%@========",[self hexToBytes:[NSString stringWithFormat:@"0501%@00000000000000",[self stringTochangeAScill:phoneString]]]);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:[self hexToBytes:[NSString stringWithFormat:@"0501%@00000000000000",[self stringTochangeAScill:phoneString]]] characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleComingSMSValue:value];
     }];
}

/**
 处理硬件返回的数据
 
 */
- (void)handleComingSMSValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];

    //抬腕手势开关设置
    if (command_id == 0x05 && key == 0x03)
    {
        
    }
}

#pragma ===========================信息提醒(command_id 为 0x05, key 为 0x03)=================================================
/**
 发送数据
 */
- (void)sendDataForComingSMS:(NSString *)SMSString
{
    NSString *uuid = @"FFF2";
    
    NSLog(@"========信息提醒:%@========",[self hexToBytes:[NSString stringWithFormat:@"0503%@00000000000000",[self stringTochangeAScill:SMSString]]]);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:[self hexToBytes:[NSString stringWithFormat:@"0503%@00000000000000",[self stringTochangeAScill:SMSString]]] characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleComingPhoneValue:value];
     }];
}

/**
 处理硬件返回的数据
 
 */
- (void)handleComingPhoneValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //抬腕手势开关设置
    if (command_id == 0x05 && key == 0x01)
    {
        
    }
}


#pragma ===========================寻找手环(command_id 为 0x06, key 为 0x04)================================================

/**
 发送数据
 */
- (void)sendDataForLookForEquipment
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x06; //command_id
    byte[1] = 0x04;  //key
    byte[2] = 0x00;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"=======寻找手环:%@======",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleLookForEquipmentValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleLookForEquipmentValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x06 && key == 0x04)
    {
       
        
    }
    
}
#pragma ===========================事件控制(command_id 为 0x07, key 为 0x01)=================================================
/**
 发送数据
 */
- (void)sendDataForPlayMusicOfType:(NSString *)type
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x07; //command_id
    byte[1] = 0x01;  //key
    if ([type isEqualToString:@"开始"]) {
        byte[2] = 0x01;
    }else if ([type isEqualToString:@"暂停"]){
        byte[2] = 0x02;
    }else if ([type isEqualToString:@"结束"]){
        byte[2] = 0x03;
    }else if ([type isEqualToString:@"上一首"]){
        byte[2] = 0x04;
    }else if ([type isEqualToString:@"下一首"]){
        byte[2] = 0x05;
    }else if ([type isEqualToString:@"单拍"]){
        byte[2] = 0x06;
    }else if ([type isEqualToString:@"连拍"]){
        byte[2] = 0x07;
    }else if ([type isEqualToString:@"音量增"]){
        byte[2] = 0x08;
    }else if ([type isEqualToString:@"音量减"]){
        byte[2] = 0x09;
    }
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"===========事件控制%@==========",data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handlePlayMusicOfTypeValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handlePlayMusicOfTypeValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    Byte states = byte[2];
    //获得设备基本信息
    if (command_id == 0x07 && key == 0x02)
    {
        if (states == 0x00) {
            
            NSLog(@"寻找手机成功");
        }else
        {
            NSLog(@"寻找手机失败");
        }
        
    }
    
}

#pragma ===========================寻找手机(command_id 为 0x07, key 为 0x02)=================================================
/**
 发送数据
 */
- (void)sendDataForLookForMyPhone
{
    NSString *uuid = @"FFF2";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[20];
    byte[0] = 0x07; //command_id
    byte[1] = 0x02;  //key
    byte[2] = 0x00;   //开始   介绍：byte[2] = 0x01;
    byte[3] = 0x00;
    byte[4] = 0x00;
    byte[5] = 0x00;
    byte[6] = 0x00;
    byte[7] = 0x00;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleLookForMyPhoneValue:value];
     }];
}


/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleLookForMyPhoneValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    Byte states = byte[2];
    //获得设备基本信息
    if (command_id == 0x07 && key == 0x02)
    {
        if (states == 0x00) {
            
            NSLog(@"寻找手机成功");
        }else
        {
             NSLog(@"寻找手机失败");
        }
        
    }
    
}
#pragma ===========================进制转换=======================================================================
//十进制转换十六进制
//- (NSString *)ToHex:(uint16_t)tmpid
//{
//    NSString *nLetterValue;
//    NSString *str =@"";
//    uint16_t ttmpig;
//    for (int i = 0; i<9; i++) {
//        ttmpig=tmpid%16;
//        tmpid=tmpid/16;
//        switch (ttmpig)
//        {
//            case 10:
//                nLetterValue =@"A";break;
//            case 11:
//                nLetterValue =@"B";break;
//            case 12:
//                nLetterValue =@"C";break;
//            case 13:
//                nLetterValue =@"D";break;
//            case 14:
//                nLetterValue =@"E";break;
//            case 15:
//                nLetterValue =@"F";break;
//            default:
//                nLetterValue = [NSString stringWithFormat:@"%u",ttmpig];
//                
//        }
//        str = [nLetterValue stringByAppendingString:str];
//        if (tmpid == 0) {
//            break;
//        }
//        
//    }
//    return str;
//}
//将十进制转化为十六进制
- (NSString *)ToHex:(int)tmpid
{
    NSString *nLetterValue;
    NSString *str =@"";
    int ttmpig;
    for (int i = 0; i<9; i++) {
        ttmpig=tmpid%16;
        tmpid=tmpid/16;
        switch (ttmpig)
        {
            case 10:
                nLetterValue =@"A";break;
            case 11:
                nLetterValue =@"B";break;
            case 12:
                nLetterValue =@"C";break;
            case 13:
                nLetterValue =@"D";break;
            case 14:
                nLetterValue =@"E";break;
            case 15:
                nLetterValue =@"F";break;
            default:
                nLetterValue = [NSString stringWithFormat:@"%u",ttmpig];
                
        }
        str = [nLetterValue stringByAppendingString:str];
        if (tmpid == 0) {
            break;
        }
    }
    //不够一个字节凑0
    if(str.length == 1){
        return [NSString stringWithFormat:@"0%@",str];
    }else{
        return str;
    }
}
//二进制转互转十六进制
// NSLog(@"====16进制=========%@",[self getBinaryByhex:nil binary:@"11111111"]);
- (NSString *)getBinaryByhex:(NSString *)hex binary:(NSString *)binary
{
    NSMutableDictionary  *hexDic = [[NSMutableDictionary alloc] init];
    hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    [hexDic setObject:@"0000" forKey:@"0"];
    [hexDic setObject:@"0001" forKey:@"1"];
    [hexDic setObject:@"0010" forKey:@"2"];
    [hexDic setObject:@"0011" forKey:@"3"];
    [hexDic setObject:@"0100" forKey:@"4"];
    [hexDic setObject:@"0101" forKey:@"5"];
    [hexDic setObject:@"0110" forKey:@"6"];
    [hexDic setObject:@"0111" forKey:@"7"];
    [hexDic setObject:@"1000" forKey:@"8"];
    [hexDic setObject:@"1001" forKey:@"9"];
    [hexDic setObject:@"1010" forKey:@"a"];
    [hexDic setObject:@"1011" forKey:@"b"];
    [hexDic setObject:@"1100" forKey:@"c"];
    [hexDic setObject:@"1101" forKey:@"d"];
    [hexDic setObject:@"1110" forKey:@"e"];
    [hexDic setObject:@"1111" forKey:@"f"];
    
    NSMutableString *binaryString=[[NSMutableString alloc] init];
    if (hex.length) {
        for (int i=0; i<[hex length]; i++) {
            NSRange rage;
            rage.length = 1;
            rage.location = i;
            NSString *key = [hex substringWithRange:rage];
            [binaryString appendString:hexDic[key]];
        }
        
    }else{
        for (int i=0; i<binary.length; i+=4) {
            NSString *subStr = [binary substringWithRange:NSMakeRange(i, 4)];
            int index = 0;
            for (NSString *str in hexDic.allValues) {
                index ++;
                if ([subStr isEqualToString:str]) {
                    [binaryString appendString:hexDic.allKeys[index-1]];
                    break;
                }
            }
        }
    }
    return binaryString;
}
//NSString转NSData
- (NSData *)hexToBytes:(NSString *)str
{
    NSMutableData* data = [NSMutableData data];
    int idx;
    for (idx = 0; idx+2 <= str.length; idx+=2) {
        NSRange range = NSMakeRange(idx, 2);
        NSString* hexStr = [str substringWithRange:range];
        NSScanner* scanner = [NSScanner scannerWithString:hexStr];
        unsigned int intValue;
        [scanner scanHexInt:&intValue];
        [data appendBytes:&intValue length:1];
    }
    return data;
}
- (Byte)strEndMinute:(NSString *)endMinute {
    // 转成 int  类型
    int endMinutes = [endMinute intValue];
    Byte endMinuteByte = (Byte)0xff&endMinutes;
    return endMinuteByte;
}
-(NSString*)stringTochangeAScill:(NSString*)nub
{
    NSString * string = @"";
    for (NSInteger i = 0; i < nub.length; i++) {
        NSString *subString = [NSString stringWithFormat:@"%hu",[nub characterAtIndex:i]];
         string = [string stringByAppendingString:subString];
    }
    return  string;
}

@end
