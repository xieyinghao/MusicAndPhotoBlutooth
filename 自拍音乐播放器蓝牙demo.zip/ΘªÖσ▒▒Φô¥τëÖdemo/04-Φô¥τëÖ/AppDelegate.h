//
//  AppDelegate.h
//  04-蓝牙
//
//  Created by vera on 16/10/14.
//  Copyright © 2016年 deli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

